/**
 * 
 */
package determineAtomPostion;

/**
 * @author imrul
 *
 */
public class AtomPostion {
	private String row;
	private String column;
	private String block;
	
	public String getRow(){
		return this.row;
	}
	
	public void setRow(String newRow){
		this.row = newRow;
	}
	
	public String getColumn(){
		return this.column;
	}
	
	public void setColumn(String newColumn){
		this.column = newColumn;
	}
	
	public String getBlock(){
		return this.block;
	}
	
	public void setBlock(String newBlock){
		this.block = newBlock;
	}
	
	
}
